// Portable MCP client helper library providing generic CRUD scenario support.
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

export async function connect({ command='node', args=[], name='portable-generic-client', version='1.0.0' }={}) {
  const transport = new StdioClientTransport({ command, args });
  const client = new Client({ name, version }, { capabilities: { tools: {} } });
  await client.connect(transport);
  return { client, transport };
}

// Create synthetic instruction entries (id, title, body, version, hash placeholder)
export function buildEntries(count=3, prefix='demo') {
  const now = Date.now();
  return Array.from({ length: count }, (_, i) => {
    const id = `${prefix}-${now}-${i+1}`;
    const body = `Instruction body ${i+1} @ ${now}`;
    return { id, title: `Title ${i+1}`, body, version: 1, hash: null };
  });
}

function classifyError(e) {
  const m = e?.message || String(e);
  if (/atomic.*readback/i.test(m)) return 'atomic_readback_failed';
  if (/not.?found/i.test(m)) return 'not_found';
  if (/conflict|version/i.test(m)) return 'conflict';
  return 'generic';
}

// Run CRUD against an index/instruction server that exposes tools: instructions/add, instructions/get, instructions/list, instructions/remove
export async function runCrudScenario({ command='node', args=['dist/server/index.js'] }, entries, { verbose=false, json=false }={}) {
  const started = performance.now();
  const summary = { created:0, listed:0, validated:0, removed:0, failures:[], durationMs:0 };
  const { client, transport } = await connect({ command, args });
  try {
    // Add entries
    for(const entry of entries) {
      try {
        const resp = await client.callTool({ name:'instructions/add', arguments:{ id:entry.id, title:entry.title, body:entry.body } });
        const text = resp.content?.[0]?.text; 
        if (text) {
          try { const parsed = JSON.parse(text); entry.hash = parsed.hash || parsed.id || null; } catch {}
        }
        summary.created++;
      } catch(e) { summary.failures.push({ phase:'add', id:entry.id, error: classifyError(e) }); if(verbose) console.error('[add-fail]', entry.id, e.message); }
    }
    // List
    let listedIds = [];
    try {
      const listResp = await client.callTool({ name:'instructions/list', arguments:{} });
      const listText = listResp.content?.[0]?.text;
      if (listText) {
        try { const arr = JSON.parse(listText); listedIds = Array.isArray(arr) ? arr.map(o=>o.id||o) : []; } catch {}
      }
      summary.listed = listedIds.length;
    } catch(e) { summary.failures.push({ phase:'list', error: classifyError(e) }); }
    // Get & validate
    for(const entry of entries) {
      try {
        const getResp = await client.callTool({ name:'instructions/get', arguments:{ id:entry.id } });
        const t = getResp.content?.[0]?.text;
        if (t) {
          let obj; try { obj = JSON.parse(t); } catch {}
          if (obj && obj.body === entry.body) { summary.validated++; }
          else { summary.failures.push({ phase:'validate', id:entry.id, mismatch:true }); }
        }
      } catch(e) { summary.failures.push({ phase:'get', id:entry.id, error: classifyError(e) }); }
    }
    // Remove
    for(const entry of entries) {
      try { await client.callTool({ name:'instructions/remove', arguments:{ id:entry.id } }); summary.removed++; }
      catch(e) { summary.failures.push({ phase:'remove', id:entry.id, error: classifyError(e) }); }
    }
  } finally {
    await transport.close();
    summary.durationMs = Math.round(performance.now() - started);
    summary.ok = summary.failures.length === 0;
    if (json) { console.log(JSON.stringify(summary)); }
    else {
      console.log('[crud] created:', summary.created, 'validated:', summary.validated, 'removed:', summary.removed, 'failures:', summary.failures.length, 'durationMs:', summary.durationMs);
      if (summary.failures.length) console.log('[crud] failures detail:', JSON.stringify(summary.failures, null, 2));
    }
  }
  return summary;
}
